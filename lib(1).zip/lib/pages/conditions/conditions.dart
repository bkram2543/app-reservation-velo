import 'package:flutter/material.dart';

class ConditionsPage extends StatefulWidget {
  const ConditionsPage({super.key});

  @override
  _ConditionsPageState createState() => _ConditionsPageState();
}

class _ConditionsPageState extends State<ConditionsPage> {
  bool isChecked = false;

  void _agreeAndProceed() {
    Navigator.pop(context); // Directly return to the welcome page
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Positioned.fill(
            child: Image.asset(
              'assets/background.webp',
              fit: BoxFit.cover,
            ),
          ),
          Column(
            children: [
              const SizedBox(height: 60), // Space from top

              const Spacer(),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.9),
                      borderRadius: BorderRadius.circular(15),
                    ),
                    padding: const EdgeInsets.all(20),
                    child: SingleChildScrollView(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            "1. يجب استخدام الخدمة وفقًا للقوانين المحلية.\n\n"
                            "2. الدراجة المستأجرة يجب إرجاعها في المحطة المحددة.\n\n"
                            "3. يتحمل المستخدم مسؤولية أي ضرر يلحق بالدراجة أثناء الاستخدام.\n\n"
                            "4. لا يُسمح باستخدام الدراجة لأغراض غير قانونية أو خطرة.\n\n"
                            "5. تحتفظ الشركة بالحق في تعليق أو إنهاء الحساب في حالة انتهاك الشروط.\n\n",
                            style: TextStyle(fontSize: 16, color: Colors.black),
                            textAlign: TextAlign.right,
                          ),
                          Row(
                            children: [
                              Checkbox(
                                value: isChecked,
                                onChanged: (value) {
                                  setState(() {
                                    isChecked = value!;
                                  });
                                },
                              ),
                              const Expanded(
                                child: Text(
                                  'أوافق على الشروط والأحكام',
                                  style: TextStyle(fontSize: 16),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: isChecked ? _agreeAndProceed : null,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      disabledBackgroundColor: Colors.grey,
                    ),
                    child: const Text(
                      'أوافق وأكمل',
                      style: TextStyle(fontSize: 18, color: Colors.white),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 40),
            ],
          ),
        ],
      ),
    );
  }
}
