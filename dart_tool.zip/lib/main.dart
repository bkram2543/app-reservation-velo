import 'package:flutter/material.dart';
import 'package:flutter_application_1/pages/welcomePage/inscre.dart';
import 'package:flutter_application_1/pages/welcomePage/connexion.dart';
import 'package:flutter_application_1/pages/welcomePage/WelcomePage.dart';
import 'pages/homePage/HomeScreen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      initialRoute: '/',
      debugShowCheckedModeBanner: false,
      routes: {
        '/': (context) => WelcomePage(),
        '/inscription': (context) => InscriptionPage(),
        '/connexion': (context) => ConnexionPage(),
        '/home': (context) => const MapScreen(),
      },
    );
  }
}
