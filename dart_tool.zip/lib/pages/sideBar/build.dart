import 'package:flutter/material.dart';

Widget buildDrawerItem(IconData icon, String title) {
  return ListTile(
    leading: Icon(icon, color: Colors.black54),
    title: Text(title),
    onTap: () {},
  );
}
