import 'package:flutter/material.dart';
import 'package:flutter_application_1/pages/prixpage/prixpage.dart';

class AppDrawer extends StatelessWidget {
  const AppDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: <Widget>[
          DrawerHeader(
            decoration: BoxDecoration(color: Colors.white),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Bonjour VotreCompte',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 10),
                Row(
                  children: [
                    Column(
                      children: [
                        Icon(Icons.linear_scale, color: Colors.blue),
                        Text(
                          '0',
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                        Text('Mètres'),
                      ],
                    ),
                    SizedBox(width: 20),
                    Column(
                      children: [
                        Icon(Icons.electric_scooter, color: Colors.blue),
                        Text(
                          '0',
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                        Text('Trajets'),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          ),
          ListTile(
            leading: Icon(Icons.payment),
            title: Text("Prix"),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => PricingPage()),
              );
            },
          ),
          ListTile(
            leading: Icon(Icons.history),
            title: Text("Historique"),
            onTap: () {},
          ),
          ListTile(
            leading: Icon(Icons.card_giftcard),
            title: Text("Bénéficier de crédits offerts"),
            onTap: () {},
          ),
          ListTile(
            leading: Icon(Icons.local_offer),
            title: Text("Codes promo"),
            onTap: () {},
          ),
          ListTile(
            leading: Icon(Icons.security),
            title: Text("Centre de sécurité"),
            onTap: () {},
          ),
          ListTile(
            leading: Icon(Icons.help),
            title: Text("Aide"),
            onTap: () {},
          ),
          ListTile(
            leading: Icon(Icons.settings),
            title: Text("Paramètres"),
            onTap: () {},
          ),
          Padding(
            padding: EdgeInsets.all(16.0),
            child: Text(
              'Doora Bike v3.202.0',
              style: TextStyle(color: Colors.grey, fontSize: 12),
            ),
          ),
        ],
      ),
    );
  }
}
