import 'package:flutter/material.dart';

class PricingPage extends StatelessWidget {
  const PricingPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Prix'),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: ListView(
        padding: EdgeInsets.all(16.0),
        children: [
          _buildListItem(
            icon: Icons.directions_bike,
            title: 'Just Ride',
            children: [
              ListTile(
                title: Text(
                  'Devenez membre et effectuez autant de trajets que vous le souhaitez',
                ),
              ),
            ],
            onTap: () {},
          ),
          _buildExpandableListItem(
            icon: Icons.confirmation_num,
            title: 'Offres',
            children: _buildPrepaidOffers(),
          ),
          _buildExpandableListItem(
            icon: Icons.all_inclusive,
            title: 'Abonnement',
            children: [
              ListTile(
                title: Text(
                  'Devenez membre et effectuez autant de trajets que vous le souhaitez',
                ),
                subtitle: Text('À partir de 800 DZD/mois'),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildListItem({
    required IconData icon,
    required String title,
    required VoidCallback onTap,
    required List<Widget> children,
  }) {
    return ListTile(
      leading: Icon(icon, color: Colors.blue),
      title: Text(title),
      trailing: Icon(Icons.arrow_forward_ios, size: 16.0),
      onTap: onTap,
    );
  }

  Widget _buildExpandableListItem({
    required IconData icon,
    required String title,
    required List<Widget> children,
  }) {
    return ExpansionTile(
      leading: Icon(icon, color: Colors.blue),
      title: Text(title),
      children: children,
    );
  }

  List<Widget> _buildPrepaidOffers() {
    final offers = [
      {'title': '30 min ', 'prix': '50 DZD', 'promo': '75%'},
      {'title': '1 Heur', 'prix': '100 DZD', 'promo': '40%'},
      {'title': '3 Heures', 'prix': '300 DZD', 'promo': '60%'},
      {'title': '5 Heures ', 'prix': '500 DZD', 'promo': '68%'},
      {'title': '12 heures', 'prix': '1200 DZD', 'promo': '82%'},
    ];
    return offers.map((offer) {
      return ListTile(
        title: Text(offer['title']!),
        subtitle: Text('Économisez jusquà ${offer['promo']}'),
        trailing: Text(
          offer['prix']!,
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
      );
    }).toList();
  }
}
