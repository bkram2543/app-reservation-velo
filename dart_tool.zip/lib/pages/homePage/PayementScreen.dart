// ignore_for_file: file_names

import 'package:flutter/material.dart';

class PaymentScreen extends StatelessWidget {
  const PaymentScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Payment")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text("Choose Payment Method"),
            ElevatedButton(
              onPressed: () {},
              child: const Text("Credit Card"),
            ),
            ElevatedButton(
              onPressed: () {},
              child: const Text("Cash"),
            ),
          ],
        ),
      ),
    );
  }
}
