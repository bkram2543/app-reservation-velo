// ignore_for_file: file_names

import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'QRscannerScreen.dart';

class MapScreen extends StatefulWidget {
  const MapScreen({super.key});

  @override
  _MapScreenState createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  final List<Marker> _markers = [];

  @override
  void initState() {
    super.initState();
    _setBikeRentalLocations();
  }

  void _setBikeRentalLocations() {
    List<LatLng> rentalLocations = [
      const LatLng(35.0, -1),
      const LatLng(30.1, -1),
      const LatLng(25.05, -1),
    ];

    setState(() {
      for (var i = 0; i < rentalLocations.length; i++) {
        _markers.add(
          Marker(
            width: 40,
            height: 40,
            point: rentalLocations[i],
            child: const Icon(Icons.location_on, color: Colors.green, size: 40),
          ),
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          FlutterMap(
            options: MapOptions(
              initialCenter: LatLng(34.89, -1.31),
              initialZoom: 9.0,
              maxZoom: 20.0,
              minZoom: 5.0,
            ),
            children: [
              TileLayer(
                urlTemplate:
                    "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
                subdomains: ['a', 'b', 'c'],
              ),
              MarkerLayer(markers: _markers),
            ],
          ),
          Positioned(
            top: 10,
            left: 10,
            child: FloatingActionButton(
              onPressed: () {},
              mini: true,
              backgroundColor: Colors.white,
              child: const Icon(Icons.menu, color: Colors.black),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const QRScannerScreen()),
          );
        },
        child: const Icon(Icons.qr_code_scanner),
      ),
    );
  }
}
