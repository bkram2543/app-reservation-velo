import 'package:flutter/material.dart';
import 'package:flutter_application_1/components/week_days_card.dart';

class HomeScreen extends StatelessWidget {
  HomeScreen({super.key});
  List<String> get Week_days_list => [
        "Saturday",
        "sunday",
        "monday",
        "tuesday",
        "wednsday",
        "thursaday",
        "friday",
      ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: const Center(
              child: Text(
            "Homepage",
            style: TextStyle(
              fontSize: 30,
            ),
          )),
          actions: [
            IconButton(
              icon: Icon(Icons.exit_to_app),
              onPressed: () {},
            ),
          ]),
      body: ListView.builder(
        physics: const BouncingScrollPhysics(
          parent: AlwaysScrollableScrollPhysics(),
        ),
        scrollDirection: Axis.vertical,
        shrinkWrap: true,
        itemCount: Week_days_list.length,
        itemBuilder: (context, index) {
          return WeekDaysCard(
            day: Week_days_list[index],
          );
        },
      ),
    );
  }
}
